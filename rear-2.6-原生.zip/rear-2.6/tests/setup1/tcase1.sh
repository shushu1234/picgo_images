#!/bin/bash

unset CONFIG_DIR

. "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"/run.sh
