# 900_umount_bootimg.sh
umount $v $TMP_DIR/boot.img >&2
#rm -f $v $TMP_DIR/boot.img >&2
